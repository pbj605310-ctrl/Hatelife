package com.example.myhtmlapp;

import android.app.Activity;
import android.content.Intent;
import android.graphics.Typeface;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.os.SystemClock;
import android.view.Gravity;
import android.view.KeyEvent;
import android.view.View;
import android.view.ViewGroup;
import android.view.WindowManager;
import android.webkit.ValueCallback;
import android.webkit.WebChromeClient;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.FrameLayout;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;

public class MainActivity extends Activity {
    private static final String ENTRY = "chess.html";
    private static final boolean FULLSCREEN = true;
    private static final boolean KEEP_AWAKE = true;
    private static final boolean SPLASH = true;
    private static final int SPLASH_BG = 0xFF0A0A0A;
    private static final int SPLASH_FG = 0xFFF2F2EE;
    private static final long SPLASH_MIN_MS = 1200;
    private static final boolean HAS_ICON = false;
    private static final String APP_NAME = "Chess";
    private static final int FILE_REQ = 1001;

    private WebView web;
    private LinearLayout splash;
    private long splashStart;
    private ValueCallback<Uri[]> filePathCallback;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        if (FULLSCREEN) {
            getWindow().addFlags(WindowManager.LayoutParams.FLAG_FULLSCREEN);
        }
        if (KEEP_AWAKE) {
            getWindow().addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON);
        }
        if (Build.VERSION.SDK_INT >= 28) {
            getWindow().getAttributes().layoutInDisplayCutoutMode =
                WindowManager.LayoutParams.LAYOUT_IN_DISPLAY_CUTOUT_MODE_SHORT_EDGES;
        }

        web = new WebView(this);
        web.setBackgroundColor(SPLASH_BG);
        FrameLayout root = new FrameLayout(this);
        root.setBackgroundColor(SPLASH_BG);
        root.addView(web, new FrameLayout.LayoutParams(
            ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT));
        setContentView(root);
        if (SPLASH) {
            buildSplash(root);
        }

        WebSettings s = web.getSettings();
        s.setJavaScriptEnabled(true);
        s.setDomStorageEnabled(true);
        s.setDatabaseEnabled(true);
        s.setAllowFileAccess(true);
        s.setAllowContentAccess(true);
        s.setAllowFileAccessFromFileURLs(true);
        s.setAllowUniversalAccessFromFileURLs(true);
        s.setMediaPlaybackRequiresUserGesture(false);
        s.setUseWideViewPort(true);
        s.setLoadWithOverviewMode(true);
        s.setBuiltInZoomControls(false);
        s.setSupportZoom(false);

        web.setWebChromeClient(new WebChromeClient() {
            // <input type="file"> support: opens the system file picker
            @Override
            public boolean onShowFileChooser(WebView view, ValueCallback<Uri[]> callback,
                                             FileChooserParams params) {
                if (filePathCallback != null) {
                    filePathCallback.onReceiveValue(null);
                }
                filePathCallback = callback;
                try {
                    startActivityForResult(params.createIntent(), FILE_REQ);
                } catch (Exception e) {
                    filePathCallback = null;
                    return false;
                }
                return true;
            }
        });
        web.setWebViewClient(new WebViewClient() {
            @Override
            public void onPageFinished(WebView view, String url) {
                hideSplashSoon();
            }
        });
        web.setOverScrollMode(View.OVER_SCROLL_NEVER);

        if (savedInstanceState != null) {
            web.restoreState(savedInstanceState);
        } else {
            web.loadUrl("file:///android_asset/www/" + ENTRY);
        }
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        if (requestCode == FILE_REQ) {
            if (filePathCallback != null) {
                filePathCallback.onReceiveValue(
                    WebChromeClient.FileChooserParams.parseResult(resultCode, data));
                filePathCallback = null;
            }
            return;
        }
        super.onActivityResult(requestCode, resultCode, data);
    }

    private void buildSplash(FrameLayout root) {
        float density = getResources().getDisplayMetrics().density;
        int pad = (int) (32 * density);

        splash = new LinearLayout(this);
        splash.setOrientation(LinearLayout.VERTICAL);
        splash.setGravity(Gravity.CENTER);
        splash.setBackgroundColor(SPLASH_BG);
        splash.setPadding(pad, pad, pad, pad);
        splash.setClickable(true);

        if (HAS_ICON) {
            int id = getResources().getIdentifier("ic_launcher", "drawable", getPackageName());
            if (id != 0) {
                int size = (int) (96 * density);
                ImageView icon = new ImageView(this);
                icon.setImageResource(id);
                LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(size, size);
                lp.bottomMargin = pad / 2;
                icon.setLayoutParams(lp);
                icon.setAlpha(0f);
                icon.setScaleX(0.6f);
                icon.setScaleY(0.6f);
                icon.animate().alpha(1f).scaleX(1f).scaleY(1f).setDuration(500).start();
                splash.addView(icon);
            }
        }

        TextView title = new TextView(this);
        title.setText(APP_NAME.toUpperCase());
        title.setTextColor(SPLASH_FG);
        title.setTextSize(26);
        title.setTypeface(Typeface.DEFAULT_BOLD);
        title.setGravity(Gravity.CENTER);
        title.setLetterSpacing(0.12f);
        title.setAlpha(0f);
        title.setScaleX(1.5f);
        title.setScaleY(1.5f);
        title.animate().alpha(1f).scaleX(1f).scaleY(1f).setDuration(650).start();
        splash.addView(title);

        root.addView(splash, new FrameLayout.LayoutParams(
            ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT));
        splashStart = SystemClock.uptimeMillis();
        splash.postDelayed(this::hideSplash, 6000); // safety net
    }

    private void hideSplashSoon() {
        if (splash == null) return;
        long wait = Math.max(0, SPLASH_MIN_MS - (SystemClock.uptimeMillis() - splashStart));
        splash.postDelayed(this::hideSplash, wait);
    }

    private void hideSplash() {
        final LinearLayout s = splash;
        if (s == null) return;
        splash = null;
        s.animate().alpha(0f).setDuration(350).withEndAction(() -> {
            ViewGroup parent = (ViewGroup) s.getParent();
            if (parent != null) parent.removeView(s);
        }).start();
    }

    @Override
    protected void onSaveInstanceState(Bundle out) {
        super.onSaveInstanceState(out);
        web.saveState(out);
    }

    @Override
    public void onWindowFocusChanged(boolean hasFocus) {
        super.onWindowFocusChanged(hasFocus);
        if (hasFocus && FULLSCREEN) {
            getWindow().getDecorView().setSystemUiVisibility(
                View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY
                | View.SYSTEM_UI_FLAG_FULLSCREEN
                | View.SYSTEM_UI_FLAG_HIDE_NAVIGATION
                | View.SYSTEM_UI_FLAG_LAYOUT_STABLE
                | View.SYSTEM_UI_FLAG_LAYOUT_FULLSCREEN
                | View.SYSTEM_UI_FLAG_LAYOUT_HIDE_NAVIGATION);
        }
    }

    @Override
    public boolean onKeyDown(int keyCode, KeyEvent event) {
        if (keyCode == KeyEvent.KEYCODE_BACK && web.canGoBack()) {
            web.goBack();
            return true;
        }
        return super.onKeyDown(keyCode, event);
    }

    @Override protected void onPause()  { super.onPause();  web.onPause();  }
    @Override protected void onResume() { super.onResume(); web.onResume(); }

    @Override
    protected void onDestroy() {
        if (web != null) {
            web.destroy();
        }
        super.onDestroy();
    }
}
